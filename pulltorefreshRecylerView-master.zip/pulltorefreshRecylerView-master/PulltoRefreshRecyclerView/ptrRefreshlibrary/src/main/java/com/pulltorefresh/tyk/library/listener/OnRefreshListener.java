package com.pulltorefresh.tyk.library.listener;

/**
 * 刷新
 * Created by tyk on 2016/11/24 0024.
 */

public interface OnRefreshListener {

    void onRefreshListener();
}
