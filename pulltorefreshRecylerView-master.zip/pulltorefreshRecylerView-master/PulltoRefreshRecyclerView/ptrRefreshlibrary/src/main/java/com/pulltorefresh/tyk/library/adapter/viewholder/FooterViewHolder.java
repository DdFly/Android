package com.pulltorefresh.tyk.library.adapter.viewholder;

import android.view.View;

/**
 * Created by tyk on 2016/11/31 0031.
 */

public class FooterViewHolder extends BaseViewHolder {

    public FooterViewHolder(View itemView) {
        super(itemView);
    }
}
