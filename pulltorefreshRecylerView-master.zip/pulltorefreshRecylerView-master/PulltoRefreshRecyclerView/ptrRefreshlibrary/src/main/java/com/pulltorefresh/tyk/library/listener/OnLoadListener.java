package com.pulltorefresh.tyk.library.listener;

/**
 * 加载更多
 * Created by tyk on 2016/11/27 0027.
 */

public interface OnLoadListener {

    void onLoadListener();
}
