package com.tyk.pulltorefresh.recyclerview.fragment;

import android.view.View;

import com.tyk.pulltorefresh.recyclerview.R;


/**
 * Created by Administrator on 2017/3/24 0024.
 */

public class FourFragment extends BaseFragment {
    @Override
    public View initView() {
        View view=View.inflate(activity, R.layout.fragment_four,null);
        return view;
    }
}
