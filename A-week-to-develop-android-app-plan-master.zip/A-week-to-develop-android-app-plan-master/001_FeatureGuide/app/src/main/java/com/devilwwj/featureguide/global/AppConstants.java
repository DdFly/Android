package com.devilwwj.featureguide.global;

/**
 * Created by devilwwj on 16/1/23.
 */
public class AppConstants {

    public static final String FIRST_OPEN = "first_open";
}
