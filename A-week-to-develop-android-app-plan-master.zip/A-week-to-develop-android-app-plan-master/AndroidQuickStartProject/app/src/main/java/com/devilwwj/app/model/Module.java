package com.devilwwj.app.model;

/**
 * com.devilwwj.model
 * Created by devilwwj on 16/2/17.
 */
public class Module {
    private String moduleName;
    private String imageUrl;

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}

