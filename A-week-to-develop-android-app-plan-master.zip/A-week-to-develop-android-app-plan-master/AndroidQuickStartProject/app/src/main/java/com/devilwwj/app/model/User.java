package com.devilwwj.app.model;

/**
 * com.devilwwj.model
 * Created by devilwwj on 16/2/17.
 */
public class User {
}
