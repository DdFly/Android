package com.devilwwj.app.http;

/**
 * 服务器连接常量类
 * com.devilwwj.http
 * Created by devilwwj on 16/2/17.
 */
public class URL {

}
